﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using STNCInterpreter;
using STNCAnalyzer;
using STNCFormers;
using System.Runtime.InteropServices;

// Interpreter, heir of Fanuc30i. In addition to the commands implemented in the parent, 
// he can execute the command G04 (dwell).

namespace sample_Fanuc30i_Mill
{
    // Main class
    public class Interpreter : MarshalByRefObject
    {
        public INCT_Interpreter NCT_GetInterface()
        {
            return new TInterpreter();
        }

        public void NCT_FreeMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }

    // List of delayed commands
    public enum TDelayedCmd
    {
        dcCmdDwell = 1
    }

    // Interpreter class
    public class TInterpreter : MarshalByRefObject, INCT_Interpreter
    {
        // SprutCAM interfaces
        private INCT_BlockExecArray BEA;
        private INCT_SysState SS;
        private INCT_CLData CLD;
        private INCT_Interpreter Parent;

        // List of registers that are implemented in the interpreter
        private TRegisterList Registers;

        // Local variables
        private Boolean DwellCmd;
        private Double Dwell;

        public TInterpreter()
        {
            // Create and fill register list
            Registers = new TRegisterList();
            Registers.IP = this;
            Registers.Fill();
        }

        ~TInterpreter()
        {
            BEA = null;
            SS = null;
            CLD = null;
            Parent = null;
        }

        // The function should return a SprutCAM string with the interpreter library identifier.
        public string GetIdentifier()
        {
            return "{73283BB9-A775-4771-9503-D63C2CD7EE89}";
        }

        // The function should return the SprutCAM interface INCT_RegisterList, 
        // which implements the list of interpreter registers
        public INCT_RegisterList GetRegisters()
        {
            return Registers;
        }

        // The method should receive and, if necessary to the interpreter, 
        // save the interfaces transmitted from SprutCAM for subsequent use. 
        // The method will be called several times: according to the number of transmitted interfaces.
        public void SetInterface(object Intf)
        {
            if (Intf is INCT_BlockExecArray) { BEA = Intf as INCT_BlockExecArray; }
            if (Intf is INCT_SysState) { SS = Intf as INCT_SysState; }
            if (Intf is INCT_CLData) { CLD = Intf as INCT_CLData; }
            if (Intf is INCT_Interpreter) { Parent = Intf as INCT_Interpreter; }
        }

        // The method informs the interpreter about the completion of the transfer of all 
        // SprutCAM interfaces and the ability to perform initialization of the interpreter.
        public void Initialize()
        {
        }

        // The method informs the interpreter about the interpretation of the next operation
        public void NextOperation()
        {
        }

        // The method passes the frame of the control program to the interpreter (or a part of the frame, 
        // depending on the current iteration of the frame translation) to attempt to read the lexeme or the 
        // semantic construction from its beginning. In case the interpreter has recognized a token or a structure, 
        // it must return the number of characters from the beginning of the line that the recognized lexeme or 
        // structure constitutes. Otherwise, returns an amount equal to 0.
        public void TransLine(string CurrentLine, out int ProcessedChars, out bool NextLine, out bool BreakLine)
        {
            ProcessedChars = 0;
            NextLine = false;
            BreakLine = false;

            // Call parent method
            if (Parent != null) { Parent.TransLine(CurrentLine, out ProcessedChars, out NextLine, out BreakLine); };
        }

        // The function should perform a register search by address, return the search result and the 
        // index of the found register.
        public bool DefineRegister(string Addr, out int Index)
        {
            INCT_BaseReg BR;
            Index = -1;

            // In the current line of the NC program was already register "DWELL"?
            if (IsActiveReg("DWELL"))
            {
                // So the "X" register is "X DWELL"
                if (Addr == "X")
                {
                    BR = SS.get_BR_ByName("X DWELL");
                    if (BR != null)
                    {
                        Index = BR.Idx;
                        BR = null;
                        return true;
                    }
                }
                
                // So the "P" register is "P DWELL"
                if (Addr == "P")
                {
                    BR = SS.get_BR_ByName("P DWELL");
                    if (BR != null)
                    {
                        Index = BR.Idx;
                        BR = null;
                        return true;
                    }
                }

            }

            // Call parent method
            if (Parent != null) { return Parent.DefineRegister(Addr, out Index); };
            return false;
        }

        // Check the register in the current line
        private bool IsActiveReg(string Name)
        {
            INCT_BaseReg BR;
            BR = SS.get_BR_ByName(Name);
            if (BR != null)
            {
                int Idx;
                return !(BEA.Find(TNCExecObj.exReg, (IntPtr)BR.Idx, 0, out Idx) == null);
            }
            return false;
        }

        // The method informs the interpreter about the end of the current frame translation 
        // and the beginning of its interpretation.
        public void BeforeInterprete()
        {
            DwellCmd = false;

            // Call parent method
            if (Parent != null) { Parent.BeforeInterprete(); };
        }

        // The method passes to the interpreter the element number from the list of objects 
        // for interpreting the current frame. The interpreter must interpret the transmitted object, 
        // i.e. by object number, determine its type and, if necessary, add a command to form the 
        // element(s) of the tool path.
        public void Interprete(int ExecNum)
        {
            INCT_BlockExecObject BEO;
            INCT_BaseReg BR;
            Boolean Used = false;

            // Get block exec object by ExecNum
            BEO = BEA.Get(ExecNum);
            try
            {
                switch (BEO.ExecType)
                {
                    // Is register
                    case TNCExecObj.exReg:
                        // Get the register
                        BR = SS.BR_ByIndex[BEO.ExecParam.ToInt32()];
                        // Find register in our list of registers
                        if (Registers.Find(BR.Name) != null)
                        {
                            // Its own register, call linked command (CmdDwell/SetDwell)
                            Registers.RunCommand(BR);
                            Used = true;
                        }
                        break;

                    // Is other object
                    case TNCExecObj.exObj:
                        if (BEO.IsOwn)
                        {
                            // Its own object
                            switch ((TDelayedCmd)BEO.ExecParam)
                            {
                                case TDelayedCmd.dcCmdDwell:
                                    // Add delay to the tool path
                                    DoDwell();
                                    break;
                            }
                            Used = true;
                        }
                        break;
                }

            }
            finally
            {
                BEO = null;
                BR = null;
            }

            if (!Used)
            {
                // Its parents block exec object, call parent Interprete method
                if (Parent != null) { Parent.Interprete(ExecNum); };
            }
        }

        // The method informs the interpreter about the end of the interpretation 
        // of the current frame.
        public void AfterInterprete()
        {
            // Call parent method
            if (Parent != null) { Parent.AfterInterprete(); };
        }

        // The function should return the end of the program to SprutCAM if the end of the program 
        // command was processed when interpreting the text of the G-code. Translation and interpretation 
        // of the G-code is completed.
        public bool EndOfProgram()
        {
            return false;
        }

        // Add delayed commad. Waiting for receiving "X" or "P" register from the NC program line.
        public void CmdDwell(INCT_BaseReg BR)
        {
            if (!DwellCmd)
            {
                AddDelayedCmd(TDelayedCmd.dcCmdDwell);
                DwellCmd = true;
            }
        }

        // Add delayed command to the block exec array (BEA)
        public void AddDelayedCmd(TDelayedCmd Cmd)
        {
            BEA.Add(TNCExecObj.exObj, (IntPtr)Cmd);
        }

        // Set dwell value
        public void SetDwell(INCT_BaseReg BR)
        {
            Dwell = BR.Flt;
        }

        // Add delay command to the tool path
        public void DoDwell()
        {
            CLD.AddDelay(Dwell);
        }
    }

    public delegate void Command(INCT_BaseReg BR);

    // Register list implementation
    public class TRegisterList : INCT_RegisterList
    {
        private List<TRegister> Items = new List<TRegister>();

        // Count of the registers
        public int Count
        { get { return Items.Count; } }

        public INCT_Register this[int index]
        { get { return Items[index]; } }

        // Add register to list
        private void Add(string Addr, string Id, string Name, string Comment, TNCSign Sign, TNCPoint Point,
            int BeforePoint, int AfterPoint, Boolean LeadingZeros, Boolean TrailingZeroes,
            TNCValueAvailType ValueAvail, double[] Values, Boolean Modal, Command Cmd)
        {
            TRegisterValues RegValues = new TRegisterValues();
            RegValues.Add(Values);

            TRegister Item = new TRegister();
            Item.Addr = Addr;
            Item.Id = Id;
            Item.Name = Name;
            Item.Comment = Comment;
            Item.Sign = Sign;
            Item.Point = Point;
            Item.BeforePoint = BeforePoint;
            Item.AfterPoint = AfterPoint;
            Item.LeadingZeros = LeadingZeros;
            Item.TrailingZeroes = TrailingZeroes;
            Item.ValueAvail = ValueAvail;
            Item.Values = RegValues;
            Item.Modal = Modal;
            Item.Cmd = Cmd;
            Items.Add(Item);
        }

        public TInterpreter IP;

        // Fill register list
        public void Fill()
        {
            Add("G", "", "DWELL", "Dwell", TNCSign.sgnNoSign, TNCPoint.pntNoPoint, 2, 0, true, false, TNCValueAvailType.vatValue, new double[] { 4 }, true, IP.CmdDwell);
            Add("", "", "X DWELL", "Specify a time or spindle speed (decimal point permitted)", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.SetDwell);
            Add("", "", "P DWELL", "Specify a time or spindle speed (decimal point not permitted)", TNCSign.sgnMinus, TNCPoint.pntNoPoint, 5, 0, false, false, TNCValueAvailType.vatValue, null, false, IP.SetDwell);
        }

        // Find register by name
        public TRegister Find(string Name)
        {
            TRegister res = Items.Find(
                delegate(TRegister It)
                {
                    return (It.Name == Name);
                }
            );
            return res;
        }

        // Run command, linked to register
        public void RunCommand(INCT_BaseReg BR)
        {
            TRegister Reg = this.Find(BR.Name);
            if ((Reg != null) & (Reg.Cmd != null))
            {
                Reg.Cmd(BR);
            }
        }
    }

    // Register implementation
    public class TRegister : INCT_Register
    {
        public string Addr { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Comment { get; set; }
        public TNCSign Sign { get; set; }
        public TNCPoint Point { get; set; }
        public int BeforePoint { get; set; }
        public int AfterPoint { get; set; }
        public Boolean LeadingZeros { get; set; }
        public Boolean TrailingZeroes { get; set; }
        public TNCValueAvailType ValueAvail { get; set; }
        public INCT_RegisterValues Values { get; set; }
        public Boolean Modal { get; set; }
        public Command Cmd { get; set; }
    }

    // Register values
    public class TRegisterValues : INCT_RegisterValues
    {
        private List<double> Items = new List<double>();

        public int Count
        { get { return Items.Count; } }

        public double this[int index]
        { get { return Items[index]; } }

        public void Add(double[] Values)
        {
            if (Values != null)
            {
                Items.AddRange(Values);
            }
        }
    }
}
