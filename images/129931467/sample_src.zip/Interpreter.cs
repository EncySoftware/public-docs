﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using STNCInterpreter;
using STNCAnalyzer;
using STNCFormers;
using System.Runtime.InteropServices;

// Interpreter Fanuc30i
namespace sample
{
    // Main class
    public class Interpreter : MarshalByRefObject
    {
        public INCT_Interpreter NCT_GetInterface()
        {
            return new TInterpreter();
        }

        public void NCT_FreeMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }

    // List of delayed commands
    public enum TDelayedCmd
    {
        dcCmdMove
    }

    // Interpreter class
    public class TInterpreter : MarshalByRefObject, INCT_Interpreter
    {
        // SprutCAM interfaces
        private INCT_BlockExecArray BEA;
        private INCT_SysState SS;
        private INCT_Equipment EQ;
        private INCT_CLData CLD;
        private INCT_Analyzer Analyzer;

        // List of registers that are implemented in the interpreter
        private TRegisterList Registers;
        private enum TRapidMove { rmNone, rmRapid, rmWorking };
        private enum TMotionType { mtLinear, mtCircularCW, mtCircularCCW };

	 	// Local variables
        private INCT_LinearMotionFormer LMF;
        private INCT_CircularMotionFormer CMF;

        private Boolean AbsDimMode;
        private TNCPlaneType LastPlane;
        private TRapidMove RapidMove;
        private TMotionType MotionType;
        private Boolean NeedWorkingFeedSet;
        private TMoveAxes MoveAxes;
        private Double Feedrate;
        private Boolean IsMPM;

        private Boolean DelayedCmdMove;

        public TInterpreter()
        {
            // Create and fill register list
            Registers = new TRegisterList();
            Registers.IP = this;
            Registers.Fill();

            AbsDimMode = true;
            LastPlane = (TNCPlaneType) 0;
            Feedrate = 0;
            IsMPM = true;

            MoveAxes = new TMoveAxes();
        }

        ~TInterpreter()
        {
            LMF = null;
            CMF = null;
            BEA = null;
            SS = null;
            EQ = null;
            CLD = null;
            Analyzer = null;
        }

        // The function should return a SprutCAM string with the interpreter library identifier.
        public string GetIdentifier()
        {
            return "{80F754D9-EE7B-47CF-A802-A9424D9F6749}";
        }

        // The function should return the SprutCAM interface INCT_RegisterList, 
        // which implements the list of interpreter registers
        public INCT_RegisterList GetRegisters()
        {
            return Registers;
        }

        // The method should receive and, if necessary to the interpreter, 
        // save the interfaces transmitted from SprutCAM for subsequent use. 
        // The method will be called several times: according to the number of transmitted interfaces.
        public void SetInterface(object Intf)
        {
            if (Intf is INCT_BlockExecArray) { BEA = Intf as INCT_BlockExecArray; }
            if (Intf is INCT_SysState) { SS = Intf as INCT_SysState; }
            if (Intf is INCT_Equipment) { EQ = Intf as INCT_Equipment; }
            if (Intf is INCT_CLData) { CLD = Intf as INCT_CLData; }
            if (Intf is INCT_Analyzer) { Analyzer = Intf as INCT_Analyzer; }
        }

        // The method informs the interpreter about the completion of the transfer of all 
        // SprutCAM interfaces and the ability to perform initialization of the interpreter.
        public void Initialize()
        {
            Analyzer.BeginUpdate();
            try
            {
                Analyzer.CanUseEqualToAssignRegister = false;
                Analyzer.LineBeginWithNumber = false;
                Analyzer.Comments.Add("(", ")");
                Analyzer.Comments.Add("(*", "*)");
                Analyzer.Comments.Add("!", "");
                Analyzer.Comments.Add("%", "");
                Analyzer.Comments.Add(";", "");
                Analyzer.Brackets.Add('[', ']');
            }
            finally
            {
                Analyzer.EndUpdate();
            }

            InitAxes();
            LMF = CLD.CreateLinearMotionFormer();
            LMF.ClearGotoMode = true;
            MoveAxes.InitLMF(LMF);
            CMF = CLD.CreateCircularMotionFormer();
        }

        // The method informs the interpreter about the interpretation of the next operation
        public void NextOperation()
        {
        }

        // The method passes the frame of the control program to the interpreter (or a part of the frame, 
        // depending on the current iteration of the frame translation) to attempt to read the lexeme or the 
        // semantic construction from its beginning. In case the interpreter has recognized a token or a structure, 
        // it must return the number of characters from the beginning of the line that the recognized lexeme or 
        // structure constitutes. Otherwise, returns an amount equal to 0.
        public void TransLine(string CurrentLine, out int ProcessedChars, out bool NextLine, out bool BreakLine)
        {
            ProcessedChars = 0;
            NextLine = false;
            BreakLine = false;
        }

        // The function should perform a register search by address, return the search result and the 
        // index of the found register.
        public bool DefineRegister(string Addr, out int Index)
        {
            Index = -1;
            return false;
        }

        // The method informs the interpreter about the end of the current frame translation 
        // and the beginning of its interpretation.
        public void BeforeInterprete()
        {
            LMF.InitBlock();
            CMF.InitBlock();
            CMF.InitCenterPoint();

            DelayedCmdMove = false;
        }

        // The method passes to the interpreter the element number from the list of objects 
        // for interpreting the current frame. The interpreter must interpret the transmitted object, 
        // i.e. by object number, determine its type and, if necessary, add a command to form the 
        // element(s) of the tool path.
        public void Interprete(int ExecNum)
        {
            INCT_BlockExecObject BEO;
            INCT_BaseReg BR;

            // Get block exec object by ExecNum
            BEO = BEA.Get(ExecNum);
            try
            {
                switch (BEO.ExecType)
                {
                    // Is register
                    case TNCExecObj.exReg:
                        // Get the register
                        BR = SS.BR_ByIndex[BEO.ExecParam.ToInt32()];
                        Registers.RunCommand(BR);
                        break;
                    // Is other object
                    case TNCExecObj.exObj:
                        switch ((TDelayedCmd)BEO.ExecParam)
                        {
                            case TDelayedCmd.dcCmdMove:
                                CmdMove();
                                break;
                        }
                        break;
                }

            }
            finally
            {
                BEO = null;
                BR = null;
            }
        }

        // The method informs the interpreter about the end of the interpretation 
        // of the current frame.
        public void AfterInterprete()
        {
        }

        // The function should return the end of the program to SprutCAM if the end of the program 
        // command was processed when interpreting the text of the G-code. Translation and interpretation 
        // of the G-code is completed.
        public bool EndOfProgram()
        {
            return false;
        }

        public void CmdAbsDimMode(INCT_BaseReg BR)
        {
            AbsDimMode = BR.Int == 90;
        }

        public void CmdSetPlane(INCT_BaseReg BR)
        {

            TNCPlaneType NewPlane = 0;
            switch (BR.Int)
            {
                case 17:
                    NewPlane = TNCPlaneType.ptXY;
                    break;
                case 18:
                    NewPlane = TNCPlaneType.ptZX;
                    break;
                case 19:
                    NewPlane = TNCPlaneType.ptYZ;
                    break;
            }

            if (LastPlane != NewPlane)
            {
                CLD.SetCurrentPlane(NewPlane);
                LastPlane = NewPlane;
            }
        }

        public void CmdInterpolation(INCT_BaseReg BR)
        {
            switch (BR.Int)
            {
                case 0:
                    if (RapidMove != TRapidMove.rmRapid) 
                    {
                        RapidMove = TRapidMove.rmRapid;
                        CLD.OutStandardFeed(TNCFeedType.ffRapid);
                        NeedWorkingFeedSet = false;
                    }
                    MotionType = TMotionType.mtLinear;
                    break;
                case 1:
                case 2:
                case 3:
                    if (RapidMove != TRapidMove.rmWorking)
                    {
                        NeedWorkingFeedSet = true;
                    }
                    switch (BR.Int)
                    {
                        case 1:
                            MotionType = TMotionType.mtLinear;
                            break;
                        case 2:
                            MotionType = TMotionType.mtCircularCW;
                            CMF.SetMode(TNCCircularMode.cmCW);
                            break;
                        case 3:
                            MotionType = TMotionType.mtCircularCCW;
                            CMF.SetMode(TNCCircularMode.cmCCW);
                            break;
                    }
                    break;
            }
            AddMoveCmd();
        }

        public void CmdAxisMove(INCT_BaseReg BR)
        {
            if (MotionType == TMotionType.mtLinear)
            {
                LMF.SetAxisValue(AbsDimMode, Axis_ByReg(BR.Name), BR.Flt);
            }
            else // mtCircular
            {
                CMF.SetEndPoint(AbsDimMode, AxisE_ByReg(BR.Name), BR.Flt);
            }

            AddMoveCmd();
        }

        public void CmdCoordSys(INCT_BaseReg BR)
        {
            LMF.SetGotoMode(TNCGotoMode.gtmPhysic);
        }

        public void CmdArcCenter(INCT_BaseReg BR)
        {
            CMF.SetCenterPoint(false, AxisC_ByReg(BR.Name), BR.Flt); // always increment
        }

        public void CmdArcRadius(INCT_BaseReg BR)
        {
            CMF.SetRadius(BR.Flt);
        }

        public void CmdFeedrate(INCT_BaseReg BR)
        {
            Feedrate = BR.Flt;
            if ((RapidMove != TRapidMove.rmRapid) | (NeedWorkingFeedSet))
            {
                CLD.OutFeed(TNCFeedType.ffWorking, Feedrate, IsMPM);
                RapidMove = TRapidMove.rmWorking;
                NeedWorkingFeedSet = false;
            }
        }

        public void CmdMove()
        {
            if (NeedWorkingFeedSet)
            {
                RapidMove = TRapidMove.rmWorking;
                CLD.OutFeed(TNCFeedType.ffWorking, Feedrate, IsMPM);
            }

            if (MotionType == TMotionType.mtLinear)
            {
                LMF.MakeWorkpath();
            }
            else
            {
                CMF.MakeWorkpath(GetLastPlane());
            }
        }

        public TNCPlaneType GetLastPlane()
        {
            if ((LastPlane >= TNCPlaneType.ptXY) & (LastPlane <= TNCPlaneType.ptZX)) 
            {
                return LastPlane;
            }
            else
            {
                return TNCPlaneType.ptXY;
            }
        }

        public void AddDelayedCmd(TDelayedCmd Cmd)
        {
            BEA.Add(TNCExecObj.exObj, (IntPtr) Cmd);
        }

        public void AddMoveCmd()
        {
            if (!DelayedCmdMove)
            {
                AddDelayedCmd(TDelayedCmd.dcCmdMove);
                DelayedCmdMove = true;
            }
        }

        public void InitAxes()
        {
            INCT_BaseReg BR;
            string Id;
            int Idx;
            for (int i = 0; i < SS.BR_Count; i++)
            {
                BR = SS.BR_ByIndex[i];
                try
                {
                    if (BR != null)
                    {
                        Id = BR.Id;
                        if (!string.IsNullOrEmpty(Id))
                        {
                            Idx = EQ.GetAxisIndex(Id);
                            if (Idx != -1)
                            {
                                MoveAxes.Add(BR.Name, Idx);
                            }
                        }
                    }
                }
                finally
                {
                    BR = null;
                }
            }
        }

        public int Axis_ByReg(string Reg)
        {
            TMoveAxis Axis = MoveAxes.Find(Reg);
            if (Axis != null)
            {
                return Axis.Idx;
            }
            else
            {
                return -1;
            }
        }

        public TNCAxisType AxisE_ByReg(string Reg)
        {
            TNCAxisType at = TNCAxisType.axX;
            if (Reg == "X") { at = TNCAxisType.axX; }
            else
            {
                if (Reg == "Y") { at = TNCAxisType.axY; }
                else { if (Reg == "Z") { at = TNCAxisType.axZ; }; };
            };
            return at;
        }

        public TNCAxisType AxisC_ByReg(string Reg)
        {
            TNCAxisType at = TNCAxisType.axX;
            if (Reg == "XC") { at = TNCAxisType.axX; }
            else
            {
                if (Reg == "YC") { at = TNCAxisType.axY; }
                else { if (Reg == "ZC") { at = TNCAxisType.axZ; }; };
            };
            return at;
        }
    }

    public class TMoveAxis
    {
        public string Name { get; set; }
        public int Idx { get; set; }
    }

    public class TMoveAxes
    {
        private List<TMoveAxis> Items = new List<TMoveAxis>();

        public void Add(string Name, int Idx)
        {
            TMoveAxis Item = new TMoveAxis();
            Item.Name = Name;
            Item.Idx = Idx;
            Items.Add(Item);
        }

        public TMoveAxis Find(string Name)
        {
            TMoveAxis res = Items.Find(
                delegate(TMoveAxis It)
                {
                    return (It.Name == Name);
                }
            );
            return res;
        }

        public void InitLMF(INCT_LinearMotionFormer LMF)
        {
            LMF.ClearAxesIndexes();
            foreach (TMoveAxis It in Items)
            {
                LMF.InitAxisIndex(It.Idx);
            }
        }

    }

    public delegate void Command(INCT_BaseReg BR);

    // Register list implementation
    public class TRegisterList : INCT_RegisterList
    {
        private List<TRegister> Items = new List<TRegister>();

        // Count of the registers
        public int Count
        { get { return Items.Count; } }

        public INCT_Register this[int index]
        { get { return Items[index]; } }

        // Add register to list
        private void Add(string Addr, string Id, string Name, string Comment, TNCSign Sign, TNCPoint Point,
            int BeforePoint, int AfterPoint, Boolean LeadingZeros, Boolean TrailingZeroes, 
            TNCValueAvailType ValueAvail, double[] Values, Boolean Modal, Command Cmd)
        {
            TRegisterValues RegValues = new TRegisterValues();
            RegValues.Add(Values);
            
            TRegister Item = new TRegister();
            Item.Addr = Addr;
            Item.Id = Id;
            Item.Name = Name;
            Item.Comment = Comment;
            Item.Sign = Sign;
            Item.Point = Point;
            Item.BeforePoint = BeforePoint;
            Item.AfterPoint = AfterPoint;
            Item.LeadingZeros = LeadingZeros;
            Item.TrailingZeroes = TrailingZeroes;
            Item.ValueAvail = ValueAvail;
            Item.Values = RegValues;
            Item.Modal = Modal;
            Item.Cmd = Cmd;
            Items.Add(Item);
        }

        public TInterpreter IP;

        // Fill register list
        public void Fill()
        {
            Add("N", "", "BlockNum", "BlockNumber", TNCSign.sgnNoSign, TNCPoint.pntNoPoint, 4, 0, false, false, TNCValueAvailType.vatValue, null, false, null);
            Add("G", "", "INTERP", "Linear and circular interpolation", TNCSign.sgnNoSign, TNCPoint.pntNoPoint, 2, 0, true, false, TNCValueAvailType.vatValue, new double[] { 0, 1, 2, 3 }, true, IP.CmdInterpolation);
            Add("G", "", "GAbsInc", "Absolute/Incremental dimension mode", TNCSign.sgnNoSign, TNCPoint.pntNoPoint, 2, 0, false, false, TNCValueAvailType.vatValue, new double[] { 90, 91 }, true, IP.CmdAbsDimMode);
            Add("G", "", "PLANE", "Plane Selection", TNCSign.sgnNoSign, TNCPoint.pntNoPoint, 2, 0, false, false, TNCValueAvailType.vatValue, new double[] { 17, 18, 19 }, true, IP.CmdSetPlane);
            Add("G", "", "COORDSYS", "Coordinate system", TNCSign.sgnNoSign, TNCPoint.pntPoint, 2, 1, false, false, TNCValueAvailType.vatValue, new double[] { 53 }, false, IP.CmdCoordSys);
            Add("X", "X", "X", "X axis coordinate value", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdAxisMove);
            Add("Y", "Y", "Y", "Y axis coordinate value", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdAxisMove);
            Add("Z", "Z", "Z", "Z axis coordinate value", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdAxisMove);
            Add("A", "A", "A", "Indexing axis, used about the X axis", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdAxisMove);
            Add("B", "B", "B", "Rotary or Indexing axis, used about the Y axis", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdAxisMove);
            Add("C", "C", "C", "Rotary or Indexing axis, used about the Z axis", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdAxisMove);
            Add("I", "", "XC", "Arc center modifier for X axis", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdArcCenter);
            Add("J", "", "YC", "Arc center modifier for Y axis", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdArcCenter);
            Add("K", "", "ZC", "Arc center modifier for Z axis", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdArcCenter);
            Add("R", "", "RC", "Arc radius designation", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdArcRadius);
            Add("F", "", "FEED", "Feedrate", TNCSign.sgnNoSign, TNCPoint.pntPoint, 4, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdFeedrate);
        }

        // Find register by name
        public TRegister Find(string Name)
        {
            TRegister res = Items.Find(
                delegate(TRegister It)
                {
                    return (It.Name == Name);
                }
            );
            return res;
        }

        // Run command, linked to register
        public void RunCommand(INCT_BaseReg BR)
        {
            TRegister Reg = this.Find(BR.Name);
            if ((Reg != null) & (Reg.Cmd != null))
            {
                Reg.Cmd(BR);
            }
        }
    }

    // Register implementation
    public class TRegister : INCT_Register
    {
        public string Addr { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Comment { get; set; }
        public TNCSign Sign { get; set; }
        public TNCPoint Point { get; set; }
        public int BeforePoint { get; set; }
        public int AfterPoint { get; set; }
        public Boolean LeadingZeros { get; set; }
        public Boolean TrailingZeroes { get; set; }
        public TNCValueAvailType ValueAvail { get; set; }
        public INCT_RegisterValues Values { get; set; }
        public Boolean Modal { get; set; }
        public Command Cmd { get; set; }
    }

    // Register values
    public class TRegisterValues : INCT_RegisterValues
    {
        private List<double> Items = new List<double>();

        public int Count
        { get { return Items.Count; } }

        public double this[int index]
        { get { return Items[index]; } }

        public void Add(double[] Values)
        {
            if (Values != null)
            {
                Items.AddRange(Values);
            }
        }
        
    }
}
