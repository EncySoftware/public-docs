﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using STNCInterpreter;
using STNCAnalyzer;
using STNCFormers;
using System.Runtime.InteropServices;

// Interpreter Fanuc30i 3-axis movement, via INCT_GeomCLData
namespace sample_geom
{
    // Main class
    public class Interpreter : MarshalByRefObject
    {
        public INCT_Interpreter NCT_GetInterface()
        {
            return new TInterpreter();
        }

        public void NCT_FreeMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }

    // List of delayed commands
    public enum TDelayedCmd
    {
        dcCmdMove
    }

    // Interpreter class
    public class TInterpreter : MarshalByRefObject, INCT_Interpreter
    {
        // SprutCAM interfaces
        private INCT_BlockExecArray BEA;
        private INCT_SysState SS;
        private INCT_Equipment EQ;
        private INCT_GeomCLData CLR;
        private INCT_Analyzer Analyzer;

        // List of registers that are implemented in the interpreter
        private TRegisterList Registers;
        private enum TRapidMove { rmNone, rmRapid, rmWorking };
        private enum TMotionType { mtLinear, mtCircularCW, mtCircularCCW };

	 	// Local variables
        private Boolean AbsDimMode;
        private TNCPlaneType LastPlane;
        private TRapidMove RapidMove;
        private TMotionType MotionType;
        private Boolean NeedWorkingFeedSet;
        private Double Feedrate;
        private Boolean IsMPM;
        private Double[] CurPoint;
        private Double[] Point;
        private Double[] Center;
        private Double Radius;
        private Boolean ByIJK;
        private Boolean CoordSys;
        private Boolean WasFirstMove;

        private Boolean DelayedCmdMove;

        public TInterpreter()
        {
            // Create and fill register list
            Registers = new TRegisterList();
            Registers.IP = this;
            Registers.Fill();

            AbsDimMode = true;
            LastPlane = (TNCPlaneType) 0;
            Feedrate = 0;
            IsMPM = true;
            RapidMove = TRapidMove.rmNone;
            NeedWorkingFeedSet = false;
            WasFirstMove = false;

            Point = new Double[3];
            Center = new Double[3];
            CurPoint = new Double[3];

            Point[0] = 0;
            Point[1] = 0;
            Point[2] = 0;

            Point.CopyTo(Center, 0);
            Point.CopyTo(CurPoint, 0);

            Radius = 0;
        }

        ~TInterpreter()
        {
            BEA = null;
            SS = null;
            EQ = null;
            CLR = null;
            Analyzer = null;
        }

        // The function should return a SprutCAM string with the interpreter library identifier.
        public string GetIdentifier()
        {
            return "{24B52165-AA96-4F75-AAF2-68038FC6EF1C}";
        }

        // The function should return the SprutCAM interface INCT_RegisterList, 
        // which implements the list of interpreter registers
        public INCT_RegisterList GetRegisters()
        {
            return Registers;
        }

        // The method should receive and, if necessary to the interpreter, 
        // save the interfaces transmitted from SprutCAM for subsequent use. 
        // The method will be called several times: according to the number of transmitted interfaces.
        public void SetInterface(object Intf)
        {
            if (Intf is INCT_BlockExecArray) { BEA = Intf as INCT_BlockExecArray; }
            if (Intf is INCT_SysState) { SS = Intf as INCT_SysState; }
            if (Intf is INCT_Equipment) { EQ = Intf as INCT_Equipment; }
            if (Intf is INCT_GeomCLData) { CLR = Intf as INCT_GeomCLData; }
            if (Intf is INCT_Analyzer) { Analyzer = Intf as INCT_Analyzer; }
        }

        // The method informs the interpreter about the completion of the transfer of all 
        // SprutCAM interfaces and the ability to perform initialization of the interpreter.
        public void Initialize()
        {
            Analyzer.BeginUpdate();
            try
            {
                Analyzer.CanUseEqualToAssignRegister = false;
                Analyzer.LineBeginWithNumber = false;
                Analyzer.Comments.Add("(", ")");
                Analyzer.Comments.Add("(*", "*)");
                Analyzer.Comments.Add("!", "");
                Analyzer.Comments.Add("%", "");
                Analyzer.Comments.Add(";", "");
                Analyzer.Brackets.Add('[', ']');
            }
            finally
            {
                Analyzer.EndUpdate();
            }
        }

        // The method informs the interpreter about the interpretation of the next operation
        public void NextOperation()
        {
        }

        // The method passes the frame of the control program to the interpreter (or a part of the frame, 
        // depending on the current iteration of the frame translation) to attempt to read the lexeme or the 
        // semantic construction from its beginning. In case the interpreter has recognized a token or a structure, 
        // it must return the number of characters from the beginning of the line that the recognized lexeme or 
        // structure constitutes. Otherwise, returns an amount equal to 0.
        public void TransLine(string CurrentLine, out int ProcessedChars, out bool NextLine, out bool BreakLine)
        {
            ProcessedChars = 0;
            NextLine = false;
            BreakLine = false;
        }

        // The function should perform a register search by address, return the search result and the 
        // index of the found register.
        public bool DefineRegister(string Addr, out int Index)
        {
            Index = -1;
            return false;
        }

        // The method informs the interpreter about the end of the current frame translation 
        // and the beginning of its interpretation.
        public void BeforeInterprete()
        {
            Point.CopyTo(Center, 0);
            Point.CopyTo(CurPoint, 0);
            DelayedCmdMove = false;
            ByIJK = true;
            CoordSys = false;

            TNC3DPoint P, N;
            CLR.GetLastPosition(out P, out N);
            Point[0] = P.X;
            Point[1] = P.Y;
            Point[2] = P.Z;
        }

        // The method passes to the interpreter the element number from the list of objects 
        // for interpreting the current frame. The interpreter must interpret the transmitted object, 
        // i.e. by object number, determine its type and, if necessary, add a command to form the 
        // element(s) of the tool path.
        public void Interprete(int ExecNum)
        {
            INCT_BlockExecObject BEO;
            INCT_BaseReg BR;

            // Get block exec object by ExecNum
            BEO = BEA.Get(ExecNum);
            try
            {
                switch (BEO.ExecType)
                {
                    // Is register
                    case TNCExecObj.exReg:
                        // Get the register
                        BR = SS.BR_ByIndex[BEO.ExecParam.ToInt32()];
                        Registers.RunCommand(BR);
                        break;
                    // Is other object
                    case TNCExecObj.exObj:
                        switch ((TDelayedCmd)BEO.ExecParam)
                        {
                            case TDelayedCmd.dcCmdMove:
                                CmdMove();
                                break;
                        }
                        break;
                }
            }
            finally
            {
                BEO = null;
                BR = null;
            }
        }

        // The method informs the interpreter about the end of the interpretation 
        // of the current frame.
        public void AfterInterprete()
        {
        }

        // The function should return the end of the program to SprutCAM if the end of the program 
        // command was processed when interpreting the text of the G-code. Translation and interpretation 
        // of the G-code is completed.
        public bool EndOfProgram()
        {
            return false;
        }

        public void CmdAbsDimMode(INCT_BaseReg BR)
        {
            AbsDimMode = BR.Int == 90;
        }

        public void CmdSetPlane(INCT_BaseReg BR)
        {
            TNCPlaneType NewPlane = 0;
            switch (BR.Int)
            {
                case 17:
                    NewPlane = TNCPlaneType.ptXY;
                    break;
                case 18:
                    NewPlane = TNCPlaneType.ptZX;
                    break;
                case 19:
                    NewPlane = TNCPlaneType.ptYZ;
                    break;
            }

            if (LastPlane != NewPlane)
            {
                CLR.SetCurrentPlane(NewPlane);
                LastPlane = NewPlane;
            }
        }

        public void CmdCoordSys(INCT_BaseReg BR)
        {
            CoordSys = true;
        }

        public void CmdInterpolation(INCT_BaseReg BR)
        {
            switch (BR.Int)
            {
                case 0:
                    if (RapidMove != TRapidMove.rmRapid) 
                    {
                        RapidMove = TRapidMove.rmRapid;
                        CLR.OutStandardFeed(TNCFeedType.ffRapid);
                        NeedWorkingFeedSet = false;
                    }
                    MotionType = TMotionType.mtLinear;
                    break;
                case 1:
                case 2:
                case 3:
                    if (RapidMove != TRapidMove.rmWorking)
                    {
                        NeedWorkingFeedSet = true;
                    }
                    switch (BR.Int)
                    {
                        case 1:
                            MotionType = TMotionType.mtLinear;
                            break;
                        case 2:
                            MotionType = TMotionType.mtCircularCW;
                            break;
                        case 3:
                            MotionType = TMotionType.mtCircularCCW;
                            break;
                    }
                    break;
            }
            WasFirstMove = true;
            AddMoveCmd();
        }

        public Double[] SetValue(Double[] P, Boolean Abs, int Index, Double Value)
        {
            Double[] Res = new Double[3];
            P.CopyTo(Res, 0);

            if (Abs)
            {
                Res[Index] = Value;
            }
            else
            {
                Res[Index] = Res[Index] + Value;
            }
            return Res;
        }

        public void CmdAxisMove(INCT_BaseReg BR)
        {
            if (CoordSys) { return; }
            if (!WasFirstMove) { return; } 

            Point = SetValue(Point, AbsDimMode, Axis_ByReg(BR.Name), BR.Flt);
            AddMoveCmd();
        }

        public void CmdArcCenter(INCT_BaseReg BR)
        {
            if (CoordSys) { return; }
            if (!WasFirstMove) { return; } 

            Center = SetValue(Center, false, AxisC_ByReg(BR.Name), BR.Flt); // always increment
            ByIJK = true;
            AddMoveCmd();
        }

        public void CmdArcRadius(INCT_BaseReg BR)
        {
            if (CoordSys) { return; }
            if (!WasFirstMove) { return; } 

            ByIJK = false;
            Radius = BR.Flt;
        }

        public void CmdFeedrate(INCT_BaseReg BR)
        {
            Feedrate = BR.Flt;
            if ((RapidMove != TRapidMove.rmRapid) | (NeedWorkingFeedSet))
            {
                CLR.OutFeed(TNCFeedType.ffWorking, Feedrate, IsMPM);
                RapidMove = TRapidMove.rmWorking;
                NeedWorkingFeedSet = false;
            }
        }

        public TNC3DPoint ToPoint(Double[] P)
        {
            TNC3DPoint Pnt;
            Pnt.X = P[0];
            Pnt.Y = P[1];
            Pnt.Z = P[2];
            return Pnt;
        }

        public Double GetDistance(Double[] P1, Double[] P2)
        {
            Double Res = Math.Pow(P1[0] - P2[0], 2) + Math.Pow(P1[1] - P2[1], 2) + Math.Pow(P1[2] - P2[2], 2);
            return Math.Sqrt(Res);
        }

        public void GetAxisByPlane(out int i, out int j)
        {
            i = 0;
            j = 1;
            if (LastPlane == TNCPlaneType.ptYZ)
            {
                i = 1;
                j = 2;
            }
            else if (LastPlane == TNCPlaneType.ptZX)
            {
                i = 2;
                j = 0;
            }
        }

        public Double Acos(Double D)
        {
            if (D < -0.999999999) { return Math.PI; }
            if (D > 0.999999999) { return 0; }
            return Math.Acos(D);
        }

        public void CmdMove()
        {
            if (NeedWorkingFeedSet)
            {
                RapidMove = TRapidMove.rmWorking;
                CLR.OutFeed(TNCFeedType.ffWorking, Feedrate, IsMPM);
            }

            if (CoordSys) { return; }

            if (CurPoint == Point) { return; }

            if (MotionType == TMotionType.mtLinear)
            {
                CLR.CutTo3d(ToPoint(Point));
            }
            else
            {
                Boolean CanBeFull;
                if (ByIJK)
                {
                    Double R1 = GetDistance(Center, Point);
                    Double R2 = GetDistance(Center, CurPoint);
                    Radius = (R1 + R2) / 2;
                    if (MotionType == TMotionType.mtCircularCW) { Radius = -Radius; }
                    CanBeFull = true;
                }
                else
                {
                    Double P = GetDistance(Point, CurPoint);
                    Double A = Acos(Math.Pow(P, 2) /(2 * P * Radius));
                    if (MotionType == TMotionType.mtCircularCW) { A = -A; }

                    Point.CopyTo(Center, 0);
                    int i, j;
                    GetAxisByPlane(out i, out j);
                    Double B = Math.Atan2(Point[j] - CurPoint[j], Point[i] - CurPoint[i]);

                    Center[i] = CurPoint[i] + Radius * Math.Cos(B + A);
                    Center[j] = CurPoint[j] + Radius * Math.Sin(B + A);

                    if (MotionType == TMotionType.mtCircularCW) { Radius = -Math.Abs(Radius); }
                    CanBeFull = false;
                }
                CLR.ArcTo2d(ToPoint(Point), ToPoint(Center), GetLastPlane(), Radius, CanBeFull);
            }
        }

        public TNCPlaneType GetLastPlane()
        {
            if ((LastPlane >= TNCPlaneType.ptXY) & (LastPlane <= TNCPlaneType.ptZX)) 
            {
                return LastPlane;
            }
            else
            {
                return TNCPlaneType.ptXY;
            }
        }

        public void AddDelayedCmd(TDelayedCmd Cmd)
        {
            BEA.Add(TNCExecObj.exObj, (IntPtr) Cmd);
        }

        public void AddMoveCmd()
        {
            if (!DelayedCmdMove)
            {
                AddDelayedCmd(TDelayedCmd.dcCmdMove);
                DelayedCmdMove = true;
            }
        }

        public int Axis_ByReg(string Reg)
        {
            int at = 0;
            if (Reg == "X") { at = 0; }
            else
            {
                if (Reg == "Y") { at = 1; }
                else { if (Reg == "Z") { at = 2; }; };
            };
            return at;
        }

        public int AxisC_ByReg(string Reg)
        {
            int at = 0;
            if (Reg == "XC") { at = 0; }
            else
            {
                if (Reg == "YC") { at = 1; }
                else { if (Reg == "ZC") { at = 2; }; };
            };
            return at;
        }
    }

    public delegate void Command(INCT_BaseReg BR);

    // Register list implementation
    public class TRegisterList : INCT_RegisterList
    {
        private List<TRegister> Items = new List<TRegister>();

        // Count of the registers
        public int Count
        { get { return Items.Count; } }

        public INCT_Register this[int index]
        { get { return Items[index]; } }

        // Add register to list
        private void Add(string Addr, string Id, string Name, string Comment, TNCSign Sign, TNCPoint Point,
            int BeforePoint, int AfterPoint, Boolean LeadingZeros, Boolean TrailingZeroes, 
            TNCValueAvailType ValueAvail, double[] Values, Boolean Modal, Command Cmd)
        {
            TRegisterValues RegValues = new TRegisterValues();
            RegValues.Add(Values);
            
            TRegister Item = new TRegister();
            Item.Addr = Addr;
            Item.Id = Id;
            Item.Name = Name;
            Item.Comment = Comment;
            Item.Sign = Sign;
            Item.Point = Point;
            Item.BeforePoint = BeforePoint;
            Item.AfterPoint = AfterPoint;
            Item.LeadingZeros = LeadingZeros;
            Item.TrailingZeroes = TrailingZeroes;
            Item.ValueAvail = ValueAvail;
            Item.Values = RegValues;
            Item.Modal = Modal;
            Item.Cmd = Cmd;
            Items.Add(Item);
        }

        public TInterpreter IP;

        // Fill register list
        public void Fill()
        {
            Add("N", "", "BlockNum", "BlockNumber", TNCSign.sgnNoSign, TNCPoint.pntNoPoint, 4, 0, false, false, TNCValueAvailType.vatValue, null, false, null);
            Add("G", "", "INTERP", "Linear and circular interpolation", TNCSign.sgnNoSign, TNCPoint.pntNoPoint, 2, 0, true, false, TNCValueAvailType.vatValue, new double[] { 0, 1, 2, 3 }, true, IP.CmdInterpolation);
            Add("G", "", "GAbsInc", "Absolute/Incremental dimension mode", TNCSign.sgnNoSign, TNCPoint.pntNoPoint, 2, 0, false, false, TNCValueAvailType.vatValue, new double[] { 90, 91 }, true, IP.CmdAbsDimMode);
            Add("G", "", "PLANE", "Plane Selection", TNCSign.sgnNoSign, TNCPoint.pntNoPoint, 2, 0, false, false, TNCValueAvailType.vatValue, new double[] { 17, 18, 19 }, true, IP.CmdSetPlane);
            Add("G", "", "COORDSYS", "Coordinate system", TNCSign.sgnNoSign, TNCPoint.pntPoint, 2, 1, false, false, TNCValueAvailType.vatValue, new double[] { 53 }, false, IP.CmdCoordSys);
            Add("X", "X", "X", "X axis coordinate value", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdAxisMove);
            Add("Y", "Y", "Y", "Y axis coordinate value", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdAxisMove);
            Add("Z", "Z", "Z", "Z axis coordinate value", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdAxisMove);
            Add("I", "", "XC", "Arc center modifier for X axis", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdArcCenter);
            Add("J", "", "YC", "Arc center modifier for Y axis", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdArcCenter);
            Add("K", "", "ZC", "Arc center modifier for Z axis", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdArcCenter);
            Add("R", "", "RC", "Arc radius designation", TNCSign.sgnMinus, TNCPoint.pntAlwaysPoint, 5, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdArcRadius);
            Add("F", "", "FEED", "Feedrate", TNCSign.sgnNoSign, TNCPoint.pntPoint, 4, 3, false, false, TNCValueAvailType.vatValue, null, false, IP.CmdFeedrate);
        }

        // Find register by name
        public TRegister Find(string Name)
        {
            TRegister res = Items.Find(
                delegate(TRegister It)
                {
                    return (It.Name == Name);
                }
            );
            return res;
        }

        // Run command, linked to register
        public void RunCommand(INCT_BaseReg BR)
        {
            TRegister Reg = this.Find(BR.Name);
            if ((Reg != null) & (Reg.Cmd != null))
            {
                Reg.Cmd(BR);
            }
        }
    }

    // Register implementation
    public class TRegister : INCT_Register
    {
        public string Addr { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Comment { get; set; }
        public TNCSign Sign { get; set; }
        public TNCPoint Point { get; set; }
        public int BeforePoint { get; set; }
        public int AfterPoint { get; set; }
        public Boolean LeadingZeros { get; set; }
        public Boolean TrailingZeroes { get; set; }
        public TNCValueAvailType ValueAvail { get; set; }
        public INCT_RegisterValues Values { get; set; }
        public Boolean Modal { get; set; }
        public Command Cmd { get; set; }
    }

    // Register values
    public class TRegisterValues : INCT_RegisterValues
    {
        private List<double> Items = new List<double>();

        public int Count
        { get { return Items.Count; } }

        public double this[int index]
        { get { return Items[index]; } }

        public void Add(double[] Values)
        {
            if (Values != null)
            {
                Items.AddRange(Values);
            }
        }
        
    }
}
